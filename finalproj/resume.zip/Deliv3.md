![opium](opiumbird.png)

# opium bird

### **Head of Drip Inc.**

Opium Bird is the creative director of Drip Inc.


### **What's he known for?**

Opium is best known for being an absolute G and the realest out here. For real. (Mostly on tiktok, though.)

### **Can he speak?**

No, Opium bird can only speak in caws, scorks, and telepathical communication.